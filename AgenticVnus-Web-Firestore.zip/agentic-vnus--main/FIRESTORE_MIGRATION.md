# Firestore migration

This build removes the application's Realtime Database transport.

## Firestore data layout

- `agent_workspaces/{code}` — pairing, ownership, plan and agent identity.
- `workspace_nodes/{workspaceId}/nodes/{encodedPath}` — granular realtime workspace data.
- `agent_connections/{workspaceId}` — dashboard connection index.
- `agent_connections/{workspaceId}/permissions/{permissionId}` — permission requests.

The `workspace_nodes` layer deliberately stores path nodes separately so a single
workspace document cannot hit Firestore's 1 MiB document limit. Existing agent
code keeps its `rtdbSet/rtdbPatch/rtdbGet/listenRTDB` function names internally
for compatibility, but those functions now use Firestore.

## Required Firebase setup

1. Enable Firestore.
2. Enable Anonymous Authentication (the desktop agent uses it).
3. Deploy `firestore.rules` from the web project.
4. Keep the existing web Firebase environment variables.
5. The desktop agent uses the same Firebase project configuration.

No Realtime Database URL is required by this build.

## Validation

All Windows Agent JavaScript files pass `node --check`.
A full Next.js build could not be executed in the offline build environment
because npm dependencies were not available locally; run `npm install` and
`npm run build` in the web project before deployment.
