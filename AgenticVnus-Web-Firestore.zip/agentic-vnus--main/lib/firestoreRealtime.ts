// lib/firestoreRealtime.ts
// RTDB-compatible API backed entirely by Firestore.
// Keeps existing UI components working while data is stored in
// granular workspace_nodes documents (no 1 MiB workspace document).

import {
  collection, deleteDoc, doc, getDoc, getDocs, onSnapshot, query, setDoc, where,
  updateDoc, serverTimestamp, type DocumentReference,
} from "firebase/firestore";
import { db } from "./firebase";

type BridgeRef = { workspaceId: string; path: string; key?: string };

function sanitize(value: any): any {
  if (value === undefined) return null;
  if (Array.isArray(value)) return value.map(sanitize);
  if (value && typeof value === "object") {
    const out: Record<string, any> = {};
    Object.entries(value).forEach(([k, v]) => { if (v !== undefined) out[k] = sanitize(v); });
    return out;
  }
  return value;
}
function normalize(path: string): string {
  return String(path || "").replace(/^\/+|\/+$/g, "");
}
function parse(path: string): BridgeRef {
  const p = normalize(path).split("/").filter(Boolean);
  if (p[0] !== "workspaces" || !p[1]) throw new Error(`Invalid workspace path: ${path}`);
  return { workspaceId: p[1], path: p.slice(2).join("/") };
}
function nodeDoc(workspaceId: string, path: string): DocumentReference {
  const key = path ? encodeURIComponent(path) : "__root__";
  return doc(db, "workspace_nodes", workspaceId, "nodes", key);
}
export function ref(_db: unknown, path: string): BridgeRef { return parse(path); }

export function onValue(r: BridgeRef, callback: (snap: { val: () => any }) => void): () => void {
  const { workspaceId, path } = r;
  let stopped = false;
  let unsub = () => {};
  let previousJson = "";

  const rebuild = async () => {
    const nodes = collection(db, "workspace_nodes", workspaceId, "nodes");
    const q = path
      ? query(nodes, where("path", ">=", path), where("path", "<", path + "\uf8ff"))
      : query(nodes);
    const snap = await getDocs(q);
    const exact = snap.docs.find(d => (d.data().path || "") === path);
    let value: any = exact?.data().value;

    if (!exact) {
      const root: Record<string, any> = {};
      let found = false;
      for (const d of snap.docs) {
        const p = d.data().path || "";
        if (!path || p.startsWith(path + "/")) {
          const child = path ? p.slice(path.length + 1) : p;
          if (!child) continue;
          found = true;
          const parts = child.split("/");
          let cur = root;
          parts.forEach((part, i) => {
            if (i === parts.length - 1) cur[part] = d.data().value;
            else cur = cur[part] ||= {};
          });
        }
      }
      value = found ? root : null;
    }

    const json = JSON.stringify(value);
    if (json !== previousJson) {
      previousJson = json;
      callback({ val: () => value });
    }
  };

  const nodes = collection(db, "workspace_nodes", workspaceId, "nodes");
  const q = path
    ? query(nodes, where("path", ">=", path), where("path", "<", path + "\uf8ff"))
    : query(nodes);
  unsub = onSnapshot(q, () => {
    rebuild().catch(err => console.error(`Firestore rebuild error (${path}):`, err));
  }, err => console.error(`Firestore listener error (${path}):`, err));

  return () => { stopped = true; unsub(); };
}

async function findAncestor(workspaceId: string, path: string): Promise<{ ref: DocumentReference; data: any; path: string } | null> {
  const parts = path.split("/").filter(Boolean);
  for (let i = parts.length - 1; i > 0; i--) {
    const parent = parts.slice(0, i).join("/");
    const snap = await getDoc(nodeDoc(workspaceId, parent));
    if (snap.exists()) return { ref: snap.ref, data: snap.data(), path: parent };
  }
  return null;
}
function setNested(root: any, parts: string[], value: any) {
  let cur = root;
  for (let i = 0; i < parts.length - 1; i++) cur = cur[parts[i]] ||= {};
  cur[parts[parts.length - 1]] = value;
}
function deleteNested(root: any, parts: string[]) {
  let cur = root;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!cur || typeof cur !== "object" || !(parts[i] in cur)) return;
    cur = cur[parts[i]];
  }
  if (cur && typeof cur === "object") delete cur[parts[parts.length - 1]];
}
export async function set(r: BridgeRef, value: any): Promise<void> {
  const exact = await getDoc(nodeDoc(r.workspaceId, r.path));
  if (exact.exists()) {
    if (value === null) return deleteDoc(exact.ref).then(() => {});
    await setDoc(exact.ref, { ...exact.data(), value: sanitize(value), updatedAt: serverTimestamp() });
    return;
  }
  const ancestor = await findAncestor(r.workspaceId, r.path);
  if (ancestor) {
    const root = sanitize(ancestor.data.value) || {};
    const parts = r.path.slice(ancestor.path.length + 1).split("/");
    if (value === null) deleteNested(root, parts); else setNested(root, parts, sanitize(value));
    await updateDoc(ancestor.ref, { value: root, updatedAt: serverTimestamp() });
    return;
  }
  if (value === null) return;
  await setDoc(nodeDoc(r.workspaceId, r.path), {
    workspaceId:r.workspaceId, path:r.path, value:sanitize(value), updatedAt:serverTimestamp(),
  });
}
export async function update(r: BridgeRef, value: Record<string, any>): Promise<void> {
  const exact = await getDoc(nodeDoc(r.workspaceId, r.path));
  if (exact.exists()) {
    if (value === null) return remove(r);
    const current = exact.data().value;
    const merged = (current && typeof current === "object" && !Array.isArray(current) &&
      value && typeof value === "object" && !Array.isArray(value)) ? {...current,...value} : value;
    await updateDoc(exact.ref, { value:sanitize(merged), updatedAt:serverTimestamp() });
    return;
  }
  const ancestor = await findAncestor(r.workspaceId, r.path);
  if (ancestor) {
    const root = sanitize(ancestor.data.value) || {};
    const parts = r.path.slice(ancestor.path.length + 1).split("/");
    const existing = parts.reduce((o,k) => o?.[k], root);
    const merged = (existing && typeof existing === "object" && !Array.isArray(existing) &&
      value && typeof value === "object" && !Array.isArray(value)) ? {...existing,...value} : value;
    setNested(root, parts, sanitize(merged));
    await updateDoc(ancestor.ref, { value:root, updatedAt:serverTimestamp() });
    return;
  }
  return set(r, value);
}
export async function remove(r: BridgeRef): Promise<void> {
  await set(r, null);
}

export async function push(r: BridgeRef, value: any): Promise<BridgeRef> {
  const key = `msg_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  const childRef = { workspaceId:r.workspaceId, path:r.path ? `${r.path}/${key}` : key, key } as BridgeRef;
  await set(childRef, value);
  return childRef;
}
